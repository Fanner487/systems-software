#ifndef MESSAGE_QUEUE_H
#define MESSAGE_QUEUE_H

void sendQueueMessage(char * message);

#endif //MESSAGE_QUEUE_H
