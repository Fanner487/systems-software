#ifndef LOG_H
#define LOG_H

void logInfo(char* log);
void logError(char* log);
void logWarning(char* log);

#endif // LOG_H
