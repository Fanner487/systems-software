#ifndef SYNCFILES_H
#define SYNCFILES_H

void syncFiles();

#endif //SYNCFILES_H
