#ifndef DATE_H
#define DATE_H

char* getCurrentDate(char * buffer);

#endif // DATE_H
