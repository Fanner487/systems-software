#ifndef FILEAUDIT_H
#define FILEAUDIT_H

void createAuditLog();
void startFileWatch();

#endif // FILEAUDIT_H
