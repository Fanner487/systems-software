#ifndef PERMISSIONS_H
#define PERMISSIONS_H

void setFilePermissions(char mode[]);

#endif //PERMISSIONS_H
