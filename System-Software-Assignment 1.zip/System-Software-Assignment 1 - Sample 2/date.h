#ifndef ASSIGNMENT1_DATE_H
#define ASSIGNMENT1_DATE_H

char* returnDate();

#endif //ASSIGNMENT1_DATE_H
