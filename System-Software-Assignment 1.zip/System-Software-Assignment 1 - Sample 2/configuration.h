#ifndef ASSIGNMENT1_CONFIGURATION_H
#define ASSIGNMENT1_CONFIGURATION_H

void read_config_file(char *config_filename, char *return_value);

#endif // ASSIGNMENT1_CONFIGURATION_H
