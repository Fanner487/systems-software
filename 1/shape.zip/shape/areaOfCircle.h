int areaOfCircle(int r);

