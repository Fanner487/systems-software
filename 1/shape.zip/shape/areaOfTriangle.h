int areaOfTriangle(int s1, int s2);

